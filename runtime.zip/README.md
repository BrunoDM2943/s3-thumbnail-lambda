# s3-thumbnail-lambda
A simples Python app to generate a thumbnail
